import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { CaseEventType, CaseStatus, NotificationType, Role, WorkOrderStatus } from "@prisma/client";
import { notifyTenantUsers } from "@/lib/notifications";

export async function POST(req: NextRequest, ctx: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "No autenticado" }, { status: 401 });

  const role = (session.user as any).role as Role;
  if (role !== Role.ADMIN && role !== Role.BACKOFFICE) {
    return NextResponse.json({ error: "No autorizado" }, { status: 403 });
  }

  const tenantId = (session.user as any).tenantId as string;
  const actorUserId = (session.user as any).id as string;
  const caseId = String(ctx.params.id);

  const body = await req.json().catch(() => ({}));
  const technicianId = String(body.technicianId ?? "").trim();
  if (!technicianId) return NextResponse.json({ error: "technicianId requerido" }, { status: 400 });

  const tech = await prisma.user.findFirst({
    where: { id: technicianId, tenantId, active: true, role: Role.TECHNICIAN },
    select: { id: true, name: true, email: true },
  });
  if (!tech) return NextResponse.json({ error: "Técnico inválido" }, { status: 400 });

  const c = await prisma.case.findFirst({
    where: { id: caseId, tenantId },
    include: { bus: true, workOrder: true },
  });
  if (!c) return NextResponse.json({ error: "Caso no encontrado" }, { status: 404 });

  const wo = await prisma.$transaction(async (tx) => {
    const workOrder =
      c.workOrder ??
      (await tx.workOrder.create({
        data: {
          tenantId,
          caseId: c.id,
          status: WorkOrderStatus.CREADA,
        },
      }));

    const updated = await tx.workOrder.update({
      where: { id: workOrder.id },
      data: {
        assignedToId: tech.id,
        assignedAt: new Date(),
        status: WorkOrderStatus.ASIGNADA,
      },
    });

    await tx.case.update({
      where: { id: c.id },
      data: { status: CaseStatus.OT_ASIGNADA },
    });

    await tx.caseEvent.create({
      data: {
        caseId: c.id,
        type: CaseEventType.ASSIGNED,
        message: `Asignado a técnico: ${tech.name ?? tech.id}`,
        meta: { technicianId: tech.id, workOrderId: updated.id, by: actorUserId },
      },
    });

    await tx.busLifecycleEvent.create({
      data: {
        busId: c.busId,
        busEquipmentId: null,
        caseId: c.id,
        workOrderId: updated.id,
        eventType: "WO_ASSIGNED",
        summary: "OT asignada a técnico",
        occurredAt: new Date(),
      },
    });

    return updated;
  });

  // FIX: notificar SOLO al técnico asignado
  await notifyTenantUsers({
    tenantId,
    userIds: [tech.id],
    type: NotificationType.CASE_ASSIGNED,
    title: "Nuevo caso asignado",
    body: `Caso: ${c.title} | Bus: ${c.bus.code} | OT: ${wo.id}`,
    href: `/work-orders/${wo.id}`,
    meta: {
      caseId: c.id,
      workOrderId: wo.id,
      technicianId: tech.id,
    },
  });

  return NextResponse.json({ ok: true, workOrderId: wo.id });
}
