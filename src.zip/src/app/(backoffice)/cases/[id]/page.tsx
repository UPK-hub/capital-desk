import Link from "next/link";
import { notFound } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { Role } from "@prisma/client";
import AssignTechnicianCard from "./ui/AssignTechnicianCard";

function badgeClass(kind: "status" | "type" | "priority", value: string | number) {
  const base = "inline-flex items-center rounded-md border px-2 py-0.5 text-xs font-medium";
  if (kind === "status") {
    const v = String(value);
    if (v === "NUEVO") return `${base} bg-blue-50 text-blue-700 border-blue-200`;
    if (v === "OT_ASIGNADA") return `${base} bg-amber-50 text-amber-800 border-amber-200`;
    if (v === "EN_EJECUCION") return `${base} bg-purple-50 text-purple-800 border-purple-200`;
    if (v === "RESUELTO") return `${base} bg-green-50 text-green-700 border-green-200`;
    if (v === "CERRADO") return `${base} bg-zinc-50 text-zinc-700 border-zinc-200`;
    return `${base} bg-zinc-50 text-zinc-700 border-zinc-200`;
  }
  if (kind === "priority") {
    const p = Number(value);
    // 1..5 (1 urgente)
    if (p <= 2) return `${base} bg-red-50 text-red-700 border-red-200`;
    if (p === 3) return `${base} bg-amber-50 text-amber-800 border-amber-200`;
    return `${base} bg-emerald-50 text-emerald-700 border-emerald-200`;
  }
  return `${base} bg-zinc-50 text-zinc-700 border-zinc-200`;
}

function fmtDate(d: Date) {
  return new Intl.DateTimeFormat("es-CO", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(d);
}

type PageProps = { params: { id: string } };

export default async function CaseDetailPage({ params }: PageProps) {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    // si tienes /login
    return (
      <div className="mx-auto max-w-5xl p-6">
        <div className="rounded-lg border p-4">
          <p className="text-sm">Debes iniciar sesión.</p>
          <Link className="text-sm underline" href="/login">
            Ir a login
          </Link>
        </div>
      </div>
    );
  }

  const role = (session.user as any).role as Role;
  if (role !== Role.ADMIN && role !== Role.BACKOFFICE) {
    return (
      <div className="mx-auto max-w-5xl p-6">
        <div className="rounded-lg border p-4">
          <p className="text-sm">No autorizado.</p>
        </div>
      </div>
    );
  }

  const tenantId = (session.user as any).tenantId as string;

  const c = await prisma.case.findFirst({
    where: { id: params.id, tenantId },
    include: {
      bus: { select: { id: true, code: true, plate: true } },
      busEquipment: {
        select: {
          id: true,
          serial: true,
          location: true,
          active: true,
          equipmentType: { select: { name: true } },
        },
      },
      workOrder: {
        include: {
          assignedTo: { select: { id: true, name: true, email: true, role: true } },
        },
      },
      events: {
        orderBy: { createdAt: "asc" },
        take: 200,
      },
      videoDownloadRequest: true,
    },
  });

  if (!c) return notFound();

  // lifecycle del bus asociado al caso/OT (para “hoja de vida” + trazabilidad)
  const lifecycle = await prisma.busLifecycleEvent.findMany({
    where: {
      busId: c.busId,
      OR: [{ caseId: c.id }, ...(c.workOrder?.id ? [{ workOrderId: c.workOrder.id }] : [])],
    },
    orderBy: { occurredAt: "asc" },
    take: 200,
  });

  // técnicos disponibles (para asignación)
  const technicians = await prisma.user.findMany({
    where: { tenantId, active: true, role: Role.TECHNICIAN },
    orderBy: { name: "asc" },
    select: { id: true, name: true, email: true },
  });

  const equipmentLabel = c.busEquipment
    ? `${c.busEquipment.equipmentType.name}${c.busEquipment.serial ? ` • ${c.busEquipment.serial}` : ""}${
        c.busEquipment.location ? ` • ${c.busEquipment.location}` : ""
      }`
    : "No aplica / No seleccionado";

  const hasWo = Boolean(c.workOrder?.id);

  return (
    <div className="mx-auto max-w-6xl p-6 space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl font-semibold">{c.title}</h1>
          <p className="text-sm text-muted-foreground">
            Caso <span className="font-mono">{c.id}</span> • Creado {fmtDate(c.createdAt)}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className={badgeClass("type", c.type)}>{c.type}</span>
          <span className={badgeClass("status", c.status)}>{c.status}</span>
          <span className={badgeClass("priority", c.priority)}>Prioridad {c.priority}</span>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Columna izquierda: contexto */}
        <div className="lg:col-span-2 space-y-6">
          <section className="rounded-xl border bg-white p-5 shadow-sm">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-semibold">Contexto</h2>
              <Link className="text-sm underline" href={`/buses/${c.bus.id}`}>
                Ver hoja de vida del bus
              </Link>
            </div>

            <div className="mt-4 grid gap-4 md:grid-cols-2">
              <div className="rounded-lg border p-3">
                <p className="text-xs text-muted-foreground">Bus</p>
                <p className="mt-1 text-sm font-medium">
                  {c.bus.code} {c.bus.plate ? `• ${c.bus.plate}` : ""}
                </p>
              </div>

              <div className="rounded-lg border p-3">
                <p className="text-xs text-muted-foreground">Equipo</p>
                <p className="mt-1 text-sm font-medium">{equipmentLabel}</p>
              </div>

              <div className="rounded-lg border p-3 md:col-span-2">
                <p className="text-xs text-muted-foreground">Descripción</p>
                <p className="mt-1 text-sm whitespace-pre-wrap">{c.description}</p>
              </div>
            </div>

            {c.type === "SOLICITUD_DESCARGA_VIDEO" && c.videoDownloadRequest ? (
              <div className="mt-5 rounded-lg border p-4">
                <h3 className="text-sm font-semibold">Solicitud descarga de video</h3>
                <div className="mt-3 grid gap-3 md:grid-cols-2">
                  <div>
                    <p className="text-xs text-muted-foreground">Procedencia</p>
                    <p className="text-sm">{c.videoDownloadRequest.origin}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Medio entrega</p>
                    <p className="text-sm">{c.videoDownloadRequest.deliveryMethod ?? "—"}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Radicado TMSA</p>
                    <p className="text-sm">{c.videoDownloadRequest.tmsaRadicado ?? "—"}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Vehículo</p>
                    <p className="text-sm">{c.videoDownloadRequest.vehicleId ?? "—"}</p>
                  </div>
                  <div className="md:col-span-2">
                    <p className="text-xs text-muted-foreground">Cámaras solicitadas</p>
                    <p className="text-sm whitespace-pre-wrap">{c.videoDownloadRequest.camerasRequested ?? "—"}</p>
                  </div>
                </div>
              </div>
            ) : null}
          </section>

          <section className="rounded-xl border bg-white p-5 shadow-sm">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-semibold">Trazabilidad</h2>
              <p className="text-xs text-muted-foreground">
                {c.events.length} eventos de caso • {lifecycle.length} eventos de bus
              </p>
            </div>

            <div className="mt-4 space-y-3">
              {/* Timeline unificado */}
              {[
                ...c.events.map((e) => ({
                  at: e.createdAt,
                  kind: "CASE" as const,
                  title: e.type,
                  message: e.message ?? "",
                  meta: e.meta,
                })),
                ...lifecycle.map((e) => ({
                  at: e.occurredAt,
                  kind: "BUS" as const,
                  title: e.eventType,
                  message: e.summary,
                  meta: { caseId: e.caseId, workOrderId: e.workOrderId, busEquipmentId: e.busEquipmentId },
                })),
              ]
                .sort((a, b) => a.at.getTime() - b.at.getTime())
                .map((it, idx) => (
                  <div key={`${it.kind}-${idx}`} className="flex gap-3">
                    <div className="mt-1 h-2 w-2 rounded-full bg-zinc-400" />
                    <div className="flex-1 rounded-lg border p-3">
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <p className="text-sm font-medium">
                            <span className="mr-2 inline-flex items-center rounded border px-1.5 py-0.5 text-[10px] text-muted-foreground">
                              {it.kind}
                            </span>
                            {it.title}
                          </p>
                          {it.message ? <p className="mt-1 text-sm text-muted-foreground">{it.message}</p> : null}
                        </div>
                        <p className="text-xs text-muted-foreground whitespace-nowrap">{fmtDate(it.at)}</p>
                      </div>

                      {it.meta ? (
                        <details className="mt-2">
                          <summary className="cursor-pointer text-xs text-muted-foreground">Ver meta</summary>
                          <pre className="mt-2 max-h-56 overflow-auto rounded bg-zinc-50 p-2 text-xs">
                            {JSON.stringify(it.meta, null, 2)}
                          </pre>
                        </details>
                      ) : null}
                    </div>
                  </div>
                ))}
            </div>
          </section>
        </div>

        {/* Columna derecha: administración */}
        <div className="space-y-6">
          <section className="rounded-xl border bg-white p-5 shadow-sm">
            <h2 className="text-base font-semibold">Orden de trabajo</h2>

            <div className="mt-3 space-y-2">
              <div className="rounded-lg border p-3">
                <p className="text-xs text-muted-foreground">Estado OT</p>
                <p className="mt-1 text-sm font-medium">{c.workOrder?.status ?? "— (no aplica)"}</p>
              </div>

              <div className="rounded-lg border p-3">
                <p className="text-xs text-muted-foreground">Técnico asignado</p>
                <p className="mt-1 text-sm font-medium">
                  {c.workOrder?.assignedTo?.name ?? (c.workOrder?.assignedToId ? c.workOrder.assignedToId : "—")}
                </p>
                {c.workOrder?.assignedAt ? (
                  <p className="mt-1 text-xs text-muted-foreground">Asignada: {fmtDate(c.workOrder.assignedAt)}</p>
                ) : null}
              </div>

              {hasWo ? (
                <Link
                  href={`/work-orders/${c.workOrder!.id}`}
                  className="inline-flex w-full items-center justify-center rounded-md bg-black px-4 py-2 text-sm text-white"
                >
                  Abrir OT
                </Link>
              ) : (
                <p className="text-xs text-muted-foreground">
                  Este tipo de caso no requiere OT (según registry) o aún no se generó.
                </p>
              )}
            </div>
          </section>

          <AssignTechnicianCard
            caseId={c.id}
            workOrderId={c.workOrder?.id ?? null}
            currentAssignedToId={c.workOrder?.assignedToId ?? null}
            technicians={technicians}
          />

          <section className="rounded-xl border bg-white p-5 shadow-sm">
            <h2 className="text-base font-semibold">Acciones</h2>
            <div className="mt-3 space-y-2">
              <Link
                href="/cases"
                className="inline-flex w-full items-center justify-center rounded-md border px-4 py-2 text-sm"
              >
                Volver a bandeja
              </Link>
              <Link
                href={`/cases/new`}
                className="inline-flex w-full items-center justify-center rounded-md border px-4 py-2 text-sm"
              >
                Crear otro caso
              </Link>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
