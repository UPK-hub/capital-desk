import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { NotificationType, Role } from "@prisma/client";
import { notifyTenantUsers } from "@/lib/notifications";

export async function GET(_: NextRequest, ctx: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "No autenticado" }, { status: 401 });

  const tenantId = (session.user as any).tenantId as string;

  const wo = await prisma.workOrder.findFirst({
    where: { id: ctx.params.id, tenantId },
    include: { preventiveReport: true, case: { include: { bus: true } } },
  });
  if (!wo) return NextResponse.json({ error: "No encontrado" }, { status: 404 });

  return NextResponse.json({ preventiveReport: wo.preventiveReport, workOrder: wo });
}

export async function PUT(req: NextRequest, ctx: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "No autenticado" }, { status: 401 });

  const tenantId = (session.user as any).tenantId as string;
  const role = (session.user as any).role as Role;

  const wo = await prisma.workOrder.findFirst({
    where: { id: ctx.params.id, tenantId },
    include: { case: { include: { bus: true } } },
  });
  if (!wo) return NextResponse.json({ error: "No encontrado" }, { status: 404 });

  if (![Role.ADMIN, Role.TECHNICIAN].includes(role)) {
    return NextResponse.json({ error: "No autorizado" }, { status: 403 });
  }

  const body = await req.json();
  const auto = {
    plate: wo.case.bus.plate ?? null,
    biarticuladoNo: wo.case.bus.code,
  };

  const saved = await prisma.preventiveReport.upsert({
    where: { workOrderId: wo.id },
    create: { workOrderId: wo.id, ...auto, ...body },
    update: { ...auto, ...body },
  });

  await notifyTenantUsers({
    tenantId,
    roles: [Role.ADMIN, Role.BACKOFFICE],
    type: NotificationType.FORM_SAVED,
    title: "Formato Preventivo guardado",
    body: `OT: ${wo.id}`,
    meta: { workOrderId: wo.id, caseId: wo.caseId },
  });

  return NextResponse.json({ preventiveReport: saved });
}
