import { prisma } from "@/lib/prisma";
import { NotificationType, Role } from "@prisma/client";
import nodemailer from "nodemailer";

type NotifyInput = {
  tenantId: string;
  roles?: Role[]; // si no se envía, notifica a todos del tenant
  userIds?: string[]; // targeting directo
  type: NotificationType;
  title: string;
  body?: string;

  /**
   * FIX: a veces tus rutas/páginas mandan href en top-level.
   * Lo persistimos dentro de meta para mantener un contrato estable.
   */
  href?: string;

  meta?: Record<string, any>;
};

function emailEnabled() {
  return Boolean(
    process.env.SMTP_HOST &&
      process.env.SMTP_USER &&
      process.env.SMTP_PASS &&
      process.env.EMAIL_FROM
  );
}

async function sendMail(to: string[], subject: string, text: string) {
  if (!emailEnabled()) return;

  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST!,
    port: Number(process.env.SMTP_PORT ?? 587),
    secure: String(process.env.SMTP_SECURE ?? "false") === "true",
    auth: {
      user: process.env.SMTP_USER!,
      pass: process.env.SMTP_PASS!,
    },
  });

  await transporter.sendMail({
    from: process.env.EMAIL_FROM!,
    to,
    subject,
    text,
  });
}

export async function notifyTenantUsers(input: NotifyInput) {
  const { tenantId, roles, userIds, type, title, body, meta, href } = input;

  const users = await prisma.user.findMany({
    where: {
      tenantId,
      active: true,
      ...(userIds?.length ? { id: { in: userIds } } : {}),
      ...(roles?.length ? { role: { in: roles } } : {}),
    },
    select: { id: true, email: true, name: true },
  });

  if (users.length === 0) return { created: 0 };

  // normalizamos meta: siempre objeto; y si hay href, lo insertamos ahí.
  const normalizedMeta: Record<string, any> | undefined = (() => {
    const base = meta ? { ...meta } : {};
    if (href) base.href = href;
    return Object.keys(base).length ? base : undefined;
  })();

  await prisma.notification.createMany({
    data: users.map((u) => ({
      tenantId,
      userId: u.id,
      type,
      title,
      body: body ?? null,
      meta: normalizedMeta,
    })),
  });

  // email opcional
  const emails = users.map((u) => u.email).filter(Boolean);
  if (emails.length && emailEnabled()) {
    const text = [
      title,
      body ? `\n${body}` : "",
      normalizedMeta ? `\n\nMeta: ${JSON.stringify(normalizedMeta)}` : "",
    ].join("");
    await sendMail(emails, title, text);
  }

  return { created: users.length };
}
