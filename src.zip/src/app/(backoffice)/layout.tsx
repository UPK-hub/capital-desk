import Link from "next/link";

export default function BackofficeLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen">
      <header className="border-b">
        <div className="mx-auto max-w-6xl px-6 py-3 flex items-center justify-between">
          <Link href="/" className="font-semibold">Capital Desk</Link>
          <nav className="flex gap-4 text-sm">
            <Link className="underline" href="/cases">Casos</Link>
            <Link className="underline" href="/buses">Buses</Link>
          </nav>
        </div>
      </header>
      <main>{children}</main>
    </div>
  );
}
