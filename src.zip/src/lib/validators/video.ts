import { z } from "zod";

export const VideoDownloadRequestSchema = z.object({
  origin: z.enum(["TRANSMILENIO_SA", "INTERVENTORIA", "CAPITAL_BUS", "OTRO"]),
  originOther: z.string().optional().nullable(),

  requestType: z.string().min(2),
  radicadoTMSA: z.string().min(1),
  radicadoTMSADate: z.string().datetime(),
  radicadoConcesionarioDate: z.string().datetime(),

  requesterName: z.string().min(2),
  requesterDocument: z.string().min(2),
  requesterRole: z.string().min(2),
  requesterPhone: z.string().min(6),
  requesterEmail: z.string().email(),

  vehicleId: z.string().min(1),

  eventStartAt: z.string().datetime(),
  eventEndAt: z.string().datetime(),

  cameras: z.string().min(1),
  deliveryMethod: z.enum(["WINSCP", "USB", "ONEDRIVE"]),
});

export type VideoDownloadRequestInput = z.infer<typeof VideoDownloadRequestSchema>;
