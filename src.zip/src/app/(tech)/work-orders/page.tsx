import Link from "next/link";

async function getWorkOrders() {
  const res = await fetch(`${process.env.NEXTAUTH_URL ?? ""}/api/work-orders`, { cache: "no-store" });
  return res.json();
}

export default async function WorkOrdersPage() {
  const data = await getWorkOrders();

  return (
    <div className="grid gap-4">
      <div>
        <h1 className="text-xl font-semibold">Órdenes de Trabajo</h1>
        <p className="text-sm text-muted-foreground">Bandeja Técnico</p>
      </div>

      <div className="rounded-xl border">
        <div className="grid grid-cols-12 border-b px-4 py-2 text-xs text-muted-foreground">
          <div className="col-span-3">Bus</div>
          <div className="col-span-3">Caso</div>
          <div className="col-span-2">Tipo</div>
          <div className="col-span-2">Estado OT</div>
          <div className="col-span-2"></div>
        </div>

        {(data.workOrders ?? []).map((wo: any) => (
          <div key={wo.id} className="grid grid-cols-12 items-center px-4 py-3 text-sm border-b last:border-b-0">
            <div className="col-span-3">
              <div className="font-medium">{wo.case.bus.code}</div>
              <div className="text-xs text-muted-foreground">{wo.case.bus.plate ?? "-"}</div>
            </div>
            <div className="col-span-3">{wo.case.title}</div>
            <div className="col-span-2">{wo.case.type}</div>
            <div className="col-span-2">{wo.status}</div>
            <div className="col-span-2 text-right">
              <Link className="underline" href={`/work-orders/${wo.id}`}>Abrir</Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
