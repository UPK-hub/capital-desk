import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export default async function BusesPage({ searchParams }: { searchParams: { q?: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return (
      <div className="mx-auto max-w-5xl p-6">
        <div className="rounded-xl border bg-white p-6">
          <p className="text-sm">No autenticado.</p>
          <Link className="underline" href="/login">
            Ir a login
          </Link>
        </div>
      </div>
    );
  }

  const tenantId = (session.user as any).tenantId as string;
  const q = (searchParams.q ?? "").trim();

  const items = await prisma.bus.findMany({
    where: {
      tenantId,
      ...(q
        ? {
            OR: [
              { code: { contains: q, mode: "insensitive" } },
              { plate: { contains: q, mode: "insensitive" } },
            ],
          }
        : {}),
    },
    orderBy: { code: "asc" },
    take: 200,
    select: { id: true, code: true, plate: true, active: true },
  });

  return (
    <div className="mx-auto max-w-6xl p-6 space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl font-semibold">Buses</h1>
          <p className="text-sm text-muted-foreground">Busca por código o placa. Accede a hoja de vida.</p>
        </div>
        <Link href="/cases/new" className="rounded-md bg-black px-4 py-2 text-sm text-white">
          Crear caso
        </Link>
      </div>

      <form className="rounded-xl border bg-white p-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div className="flex-1">
          <input
            name="q"
            defaultValue={q}
            placeholder="Buscar por código (K1401) o placa…"
            className="h-10 w-full rounded-md border px-3 text-sm outline-none focus:ring-2 focus:ring-black/10"
          />
        </div>
        <div className="flex gap-2">
          <button className="rounded-md bg-black px-4 py-2 text-sm text-white" type="submit">
            Buscar
          </button>
          <Link className="rounded-md border px-4 py-2 text-sm" href="/buses">
            Limpiar
          </Link>
        </div>
      </form>

      <section className="rounded-xl border bg-white shadow-sm">
        <div className="border-b p-5 flex items-center justify-between">
          <h2 className="text-base font-semibold">Resultados</h2>
          <div className="text-sm text-muted-foreground">{items.length} buses</div>
        </div>

        <div className="p-5 overflow-auto">
          <table className="w-full text-sm">
            <thead className="text-xs text-muted-foreground">
              <tr className="border-b">
                <th className="py-2 text-left">Código</th>
                <th className="py-2 text-left">Placa</th>
                <th className="py-2 text-left">Estado</th>
                <th className="py-2 text-left"></th>
              </tr>
            </thead>
            <tbody>
              {items.length === 0 ? (
                <tr>
                  <td colSpan={4} className="py-6 text-muted-foreground">
                    Sin resultados.
                  </td>
                </tr>
              ) : (
                items.map((b) => (
                  <tr key={b.id} className="border-b last:border-b-0">
                    <td className="py-2 font-medium">{b.code}</td>
                    <td className="py-2">{b.plate ?? "—"}</td>
                    <td className="py-2">{b.active ? "ACTIVO" : "INACTIVO"}</td>
                    <td className="py-2">
                      <Link className="underline" href={`/buses/${b.id}`}>
                        Hoja de vida
                      </Link>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
