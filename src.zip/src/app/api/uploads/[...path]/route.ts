import { NextRequest } from "next/server";
import fs from "fs";
import path from "path";
import { uploadsDir } from "@/lib/uploads";

export const runtime = "nodejs";

export async function GET(req: NextRequest, ctx: { params: { path: string[] } }) {
  const rel = (ctx.params.path || []).join("/");
  const base = uploadsDir();
  const filePath = path.join(base, rel);

  if (!filePath.startsWith(base)) return new Response("Invalid path", { status: 400 });
  if (!fs.existsSync(filePath)) return new Response("Not found", { status: 404 });

  const stream = fs.createReadStream(filePath);
  // @ts-expect-error - Web stream interop acceptable in Node runtime
  return new Response(stream, { status: 200 });
}
